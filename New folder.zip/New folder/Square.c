#include <stdio.h>
int main(){

  float area, side;

    printf("Enter the length of side of a square\n");
    scanf("%f", &side);

    area = side * side;
    printf("Area of a Square is %0.2f \n ", area);

}
