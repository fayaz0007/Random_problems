
#include<stdio.h>

int main(){
  float b,h,area;
  printf("Plese enter the base: ");
  scanf("%f",&b);
  printf("Plese enter the height: ");
  scanf("%f",&h);

  area = 0.5*b*h;
  printf("The area of triangle is %.2f",area);
}


